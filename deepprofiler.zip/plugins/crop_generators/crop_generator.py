import deepprofiler.imaging.cropping 


GeneratorClass = deepprofiler.imaging.cropping.CropGenerator

SingleImageGeneratorClass = deepprofiler.imaging.cropping.SingleImageCropGenerator
